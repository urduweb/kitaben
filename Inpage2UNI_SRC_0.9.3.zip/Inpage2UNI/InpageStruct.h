#pragma once

class CInpageStruct
{
public:
	BYTE left;
	BYTE right;
	CString urduNCR;

public:
	CInpageStruct(void);
public:
	virtual ~CInpageStruct(void);
};
