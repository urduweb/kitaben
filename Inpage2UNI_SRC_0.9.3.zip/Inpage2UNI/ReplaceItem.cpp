#include "StdAfx.h"
#include "ReplaceItem.h"

CReplaceItem::CReplaceItem(void)
{
	sBadString = _T("");
	sGoodString = _T("");
}

CReplaceItem::~CReplaceItem(void)
{
}
