#include "StdAfx.h"
#include "Settings.h"
#include "IniFile.h"
#include "Utility.h"

CSettings::CSettings(void)
{
	Init();
}

CSettings::~CSettings(void)
{
}

bool CSettings::Init(void)
{
	CIniFile iniFile;
	string fileName = CUtility::GetExeDir();
	fileName += _T("inp2uni.ini");
	
	//
	string sec = "Corrections";
	
	string key = "ReverseUrduNumbers";	
	string res = iniFile.GetValue(key, sec, fileName);
	m_bReverseUrduNumbers = res == "1" ? true : false;

	key = "CorrectMedialBarriYeh";	
	res = iniFile.GetValue(key, sec, fileName);
	m_bCorrectMedialBarriYeh = res == "1" ? true : false;

	key = "CorrectHamzaInitialMedialForms";
	res = iniFile.GetValue(key, sec, fileName);
	m_bCorrectHamzaInitialMedialForms = res == "1" ? true : false;

	key = "CorrectCompundAlifMadda";	
	res = iniFile.GetValue(key, sec, fileName);
	m_bCorrectCompundAlifMadda = res == "1" ? true : false;

	key = "CorrectCompundHeyHamza";	
	res = iniFile.GetValue(key, sec, fileName);
	m_bCorrectCompundHeyHamza = res == "1" ? true : false;

	key = "CorrectDoZabar2Tanween";	
	res = iniFile.GetValue(key, sec, fileName);
	m_bCorrectDoZabar2Tanween = res == "1" ? true : false;

	key = "CorrectCompundHamzaWoW";	
	res = iniFile.GetValue(key, sec, fileName);
	m_bCorrectCompundHamzaWoW = res == "1" ? true : false;

	key = "CorrectOrphanAerab";	
	res = iniFile.GetValue(key, sec, fileName);
	m_bCorrectOrphanAerab = res == "1" ? true : false;
	
	//
	sec = "Output";
	
	key = "HTML";	
	res = iniFile.GetValue(key, sec, fileName);
	m_bHTML = res == "1" ? true : false;

	key = "Text";	
	res = iniFile.GetValue(key, sec, fileName);
	m_bText = res == "1" ? true : false;

	key = "WriteBOM";	
	res = iniFile.GetValue(key, sec, fileName);
	m_bWriteBOM = res == "1" ? true : false;

	//
	sec = "Debug";
	
	key = "DebugMode";	
	res = iniFile.GetValue(key, sec, fileName);
	m_bDebugMode = res == "1" ? true : false;


	//
	sec = "Replacements";

	key = "UseExternalReplacementFile";	
	res = iniFile.GetValue(key, sec, fileName);
	m_bUseExternalReplacementFile = res == "1" ? true : false;

	key = "ExternalReplacementFileName";	
	res = iniFile.GetValue(key, sec, fileName);
	m_sExternalReplacementFileName = res.c_str();

	return true;
}
