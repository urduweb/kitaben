#include "StdAfx.h"
#include "Utility.h"

CUtility::CUtility(void)
{
}

CUtility::~CUtility(void)
{
}

CString CUtility::GetExeDir()
{
	char szPath[1024];
	
	GetModuleFileName(AfxGetApp()->m_hInstance, szPath, sizeof(szPath));
	
	char* ptr = strrchr(szPath, '\\');
	
	if (ptr) ptr[1] = '\0';
	
	ASSERT(strlen(szPath) < sizeof(szPath));
	
	return szPath;
}

int CUtility::Explode(CString sInput, char sBreakString, CString& left, CString& right)
{
	int sz = sInput.GetLength();
	
	bool first = true;
	bool second = false;

	for (int i = 0; i < sz; i++)
	{
		char chTemp = sInput[i];

		if (chTemp == sBreakString)
		{
			first = false;
			second = true;

			continue;
		}

		if (first == true)
			left += chTemp;
		else
			right += chTemp;
	}

	return 0;
}