// Inpage2UniDlg.h : header file
//

#pragma once

#include "InpageStruct.h"
#include "ReplaceItem.h"
#include "Settings.h"

class CInpageStruct;
typedef CArray<CInpageStruct, CInpageStruct&> InpageStrucList;
typedef CArray<CReplaceItem, CReplaceItem&> ReplaceItemList;

// CInpage2UniDlg dialog
class CInpage2UniDlg : public CDialog
{
// Construction
public:
	CInpage2UniDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_INPAGE2UNI_DIALOG };

private:
	BYTE*			m_pData;
	DWORD			m_dwLen;
	int				m_iCorrections;
	int				m_iUnResolved;
	InpageStrucList	m_lstInpageStruct;
	CSettings		m_Settings;
	ReplaceItemList	m_lstReplaceItems;
	int				m_iReplacements;
	
public:
	void		CleanUp();
	CString		NCR2Unicode(CString sFileData);
	int			LoadFile(const CString& sFileName);
	int			InitStruct();
	int			LookUp(BYTE left, BYTE right, CString& sNCR);
	void		NewEntry(BYTE left, BYTE right, CString urduNCR);
	bool		WriteToHTMLFile();
	bool		WriteToTextFile();	// not actually write, but conversion
	int			Correct();
	int			PostCorrect();
	int			ReadExternalReplacementFile(CString sExternalReplacementFileName);
	int			ExternalReplace();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

public:
	CString m_sOutput;
	CString m_strOutHTMLFile;
	CString m_strInFilePath;
	CString m_strStatusText;

public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnClose();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedButtonBrowse();
	afx_msg void OnBnClickedButtonView();
};
