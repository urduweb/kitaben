#pragma once

class CSettings
{
public:
	CSettings(void);
	virtual ~CSettings(void);

public:
	bool	ReverseUrduNumbers() { return m_bReverseUrduNumbers; };
	bool	CorrectMedialBarriYeh() { return m_bCorrectMedialBarriYeh; };
	bool	CorrectHamzaInitialMedialForms() { return m_bCorrectHamzaInitialMedialForms; };
	bool	CorrectCompundHeyHamza() { return m_bCorrectCompundHeyHamza; };
	bool	CorrectCompundAlifMadda() { return m_bCorrectCompundAlifMadda; };
	bool	CorrectDoZabar2Tanween() { return m_bCorrectDoZabar2Tanween; };
	bool	CorrectCompundHamzaWoW() { return m_bCorrectCompundHamzaWoW; };
	bool	CorrectOrphanAerab() { return m_bCorrectOrphanAerab; };	
	bool	SaveAsHTML() { return m_bHTML; };
	bool	SaveAsText() { return m_bText; };
	bool	WriteBOM() { return m_bWriteBOM; };	
	bool	DebugMode() { return m_bDebugMode; };
	bool	UseExternalReplacementFile() { return m_bUseExternalReplacementFile; };
	CString	ExternalReplacementFileName() { return m_sExternalReplacementFileName; };

private:
	bool	m_bHTML;
	bool	m_bText;
	bool	m_bWriteBOM;
	bool	m_bCorrectOrphanAerab;
	bool	m_bCorrectCompundHamzaWoW;
	bool	m_bCorrectDoZabar2Tanween;
	bool	m_bReverseUrduNumbers;
	bool	m_bCorrectCompundAlifMadda;
	bool	m_bCorrectMedialBarriYeh;
	bool	m_bCorrectHamzaInitialMedialForms;
	bool	m_bCorrectCompundHeyHamza;
	bool	m_bDebugMode;
	bool	m_bUseExternalReplacementFile;
	CString	m_sExternalReplacementFileName;

	CString	m_sFileName;

private:	
	bool	Init(void);	// load variables from file
};
