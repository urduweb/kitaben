#pragma once

class CReplaceItem
{
public:
	CReplaceItem(void);
	~CReplaceItem(void);

public:
	CString sBadString;
	CString sGoodString;
};
