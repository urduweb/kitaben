#include "StdAfx.h"
#include "InpageStruct.h"

CInpageStruct::CInpageStruct(void)
{
	left    = 0;
	right   = 0;
	urduNCR = _T("");
}

CInpageStruct::~CInpageStruct(void)
{
}
