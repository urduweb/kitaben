#pragma once

// class for utility functions that do not belong to anywhere else
class CUtility
{
public:
	CUtility(void);
	virtual ~CUtility(void);
public:
	static CString	GetExeDir();
	static int		Explode(CString sInput, char sBreakString, CString& left, CString& right);
};
