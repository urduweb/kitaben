// Inpage2UniDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Inpage2Uni.h"
#include "Inpage2UniDlg.h"
#include "InpageStruct.h"

#include "CStdiofile_UTF8.h"
#include "Utility.h"

#include <iostream>
#include <fstream>
#include <string>
using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define E_OK			0
#define E_FILENOTFOUND	1
#define E_FILEOPENFAIL	2
#define E_MEMALLOCFAIL	3
#define E_FILEREADERROR	4
#define E_NOTFOUND		5

// CHelpDlg dialog used for App help

class CHelpDlg : public CDialog
{
public:
	CHelpDlg();

// Dialog Data
	enum { IDD = IDD_HELPBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CHelpDlg::CHelpDlg() : CDialog(CHelpDlg::IDD)
{
}

void CHelpDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CHelpDlg, CDialog)
END_MESSAGE_MAP()

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CInpage2UniDlg dialog

CInpage2UniDlg::CInpage2UniDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CInpage2UniDlg::IDD, pParent)
	, m_sOutput(_T(""))
	, m_strOutHTMLFile(_T(""))
	, m_strInFilePath(_T(""))
	, m_strStatusText(_T(""))
	, m_pData(NULL)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_dwLen = 0;
}

void CInpage2UniDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_sOutput);
	DDX_Text(pDX, IDC_EDIT3, m_strOutHTMLFile);
	DDX_Text(pDX, IDC_EDIT2, m_strInFilePath);
	DDX_Text(pDX, IDC_STATUSBAR, m_strStatusText);
}

BEGIN_MESSAGE_MAP(CInpage2UniDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDOK, &CInpage2UniDlg::OnBnClickedOk)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDCANCEL, &CInpage2UniDlg::OnBnClickedCancel)
	ON_BN_CLICKED(IDC_BUTTON_BROWSE, &CInpage2UniDlg::OnBnClickedButtonBrowse)
	ON_BN_CLICKED(IDC_BUTTON_VIEW, &CInpage2UniDlg::OnBnClickedButtonView)
END_MESSAGE_MAP()


// CInpage2UniDlg message handlers

BOOL CInpage2UniDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);
	
	// IDM_HELPBOX must be in the system command range.
	ASSERT((IDM_HELPBOX & 0xFFF0) == IDM_HELPBOX);
	ASSERT(IDM_HELPBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);

		CString strHelpMenu;
		strHelpMenu.LoadString(IDS_HELPBOX);

		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			// TODO!!! implement help dialog box
			//pSysMenu->AppendMenu(MF_STRING, IDM_HELPBOX, strHelpMenu);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);			
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	CleanUp();

	if (InitStruct() != E_OK)
	{
		AfxMessageBox(_T("Critical: InitStruct() failed!"));
	}

	m_strStatusText = _T("Ready.");	
	UpdateData(FALSE);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CInpage2UniDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else if ((nID & 0xFFF0) == IDM_HELPBOX)
	{
		CHelpDlg dlgHelp;
		dlgHelp.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CInpage2UniDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
// the minimized window.
HCURSOR CInpage2UniDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CInpage2UniDlg::OnBnClickedOk()
{
	CTime tmStart = CTime::GetCurrentTime();
	
	UpdateData(TRUE);
	BeginWaitCursor();
	CleanUp();

	m_strStatusText = _T("Step 1: Loading file...");
	UpdateData(FALSE);

	if (!LoadFile(m_strInFilePath))
	{
		// ok to proceed
		CString sTmp = _T("");
		CString sBuf = _T("");
		
		m_strStatusText = _T("Step 2: Converting text...");
		UpdateData(FALSE);
	
		for (DWORD i = 0; i < m_dwLen;)
		{
			int t = m_pData[i];

			if (t == 4)	// urdu char
			{
				if (LookUp(m_pData[i], m_pData[i+1], sTmp) == E_OK)
				{
					if (m_Settings.ReverseUrduNumbers())
					{
						if (sTmp == _T("&#1777;") ||  // urdu digit, buffer it
							sTmp == _T("&#1778;") || 
							sTmp == _T("&#1779;") || 
							sTmp == _T("&#1780;") || 
							sTmp == _T("&#1781;") || 
							sTmp == _T("&#1782;") ||
							sTmp == _T("&#1783;") ||
							sTmp == _T("&#1784;") ||
							sTmp == _T("&#1785;") ||
							sTmp == _T("&#1776;"))
						{
							sBuf.Insert(0, sTmp);
						}
						else
						{
							m_sOutput += sBuf + sTmp;
							sBuf = _T("");
						}
					}					
					else
					{
						m_sOutput += sTmp;
					}
				}
				else
				{
					if (m_Settings.DebugMode())
					{
						CString sDeb = _T("");
						
						sDeb.Format(_T("L:%d R:%d"), m_pData[i], m_pData[i+1]);
						
						m_sOutput += "[";
						m_sOutput += sDeb;
						m_sOutput += "]";
						m_iUnResolved++;
					}
				}

				i += 2;
			}
			else	// ASCII char
			{
				CString sTmp = _T("");
				
				if (LookUp(-1, m_pData[i], sTmp) == E_OK)
				{
					m_sOutput += sTmp;
				}
				else	// not found
				{
					if (m_Settings.DebugMode())
					{
						CString sDeb = _T("");
						
						sDeb.Format(_T("L:%d"), m_pData[i]);
						
						m_sOutput += "[";
						m_sOutput += sDeb;
						m_sOutput += "]";
						m_iUnResolved++;
					}
				}

				i += 1;
			}
		}
	
		m_strStatusText = _T("Step 3: Correcting errors...");	
		UpdateData(FALSE);
		m_iCorrections = Correct();

		// mending
		PostCorrect();

		if (m_Settings.UseExternalReplacementFile())
		{
			m_strStatusText = _T("Step 4: Replacing content using external file...");
			UpdateData(FALSE);
			
			if (ReadExternalReplacementFile(m_Settings.ExternalReplacementFileName()) > 0)
				m_iReplacements = ExternalReplace();
		}

		if (m_Settings.SaveAsHTML())
		{
			m_strStatusText = _T("Step 5: Writing output (as HTML)...");
			UpdateData(FALSE);
			WriteToHTMLFile();
		}

		if (m_Settings.SaveAsText())
		{
			m_strStatusText = _T("Step 6: Writing output (as text)...");
			UpdateData(FALSE);
			WriteToTextFile();
		}
	}
	else
	{
		m_strStatusText = _T("Error: Failed to read file.");
		UpdateData(FALSE);
		EndWaitCursor();

		return;
	}
	
	CTime tmEnd = CTime::GetCurrentTime();
	CTimeSpan tsElapsed = tmEnd - tmStart;

	if (m_Settings.DebugMode())
	{
		m_strStatusText.Format(_T("Done in %d minute(s) %d second(s), with %d corrections. %d characters unresolved."), tsElapsed.GetMinutes(), tsElapsed.GetSeconds(), m_iCorrections, m_iUnResolved);
	}
	else
	{
		m_strStatusText.Format(_T("Done in %d minute(s) %d second(s), with %d corrections."), tsElapsed.GetMinutes(), tsElapsed.GetSeconds(), m_iCorrections);
	}

	UpdateData(FALSE);
	EndWaitCursor();

	//OnOK();
}

int CInpage2UniDlg::LoadFile(const CString& sFileName)
{
	if (sFileName == _T(""))
		return E_FILENOTFOUND;

	CFile file;
	CFileException ex;
	
	// open file for reading
	if (!file.Open(sFileName, CFile::modeRead, &ex))
	{
		return E_FILEOPENFAIL;
	}

	// get length of file 
	m_dwLen = (DWORD) file.GetLength();

	// allocate the buffer to hold file data
	try
	{
		m_pData = new BYTE[m_dwLen]; 
		memset(m_pData, NULL, m_dwLen);
	}
	catch(CMemoryException* ex)
	{
		ex->Delete();
		file.Close();
		
		return E_MEMALLOCFAIL;
	}

	// read the file data
	try
	{
		file.Read(m_pData, m_dwLen);
	}
	catch(CFileException* ex)
	{
		ex->Delete();
		file.Abort();

		return E_FILEREADERROR;
	}

	file.Close();

	return E_OK;
}
void CInpage2UniDlg::OnClose()
{
	CleanUp();

	CDialog::OnClose();
}

void CInpage2UniDlg::OnBnClickedCancel()
{
	CleanUp();

	OnCancel();
}

int CInpage2UniDlg::InitStruct()
{
	// init inpage to unicode table
	
	NewEntry(4, 144, _T("&#1586;"));
	NewEntry(4, 147, _T("&#1588;"));
	NewEntry(4, 136, _T("&#1670;"));	// chay
	NewEntry(4, 150, _T("&#1591;"));
	NewEntry(4, 130, _T("&#1576;"));	// bay
	NewEntry(4, 160, _T("&#1606;"));
	NewEntry(4, 159, _T("&#1605;"));
	NewEntry(4, 129, _T("&#1575;"));	// alif
	NewEntry(4, 146, _T("&#1587;"));
	NewEntry(4, 139, _T("&#1583;"));
	NewEntry(4, 154, _T("&#1601;"));
	NewEntry(4, 157, _T("&#1711;"));
	NewEntry(4, 167, _T("&#1726;"));
	NewEntry(4, 135, _T("&#1580;"));
	NewEntry(4, 156, _T("&#1705;"));
	NewEntry(4, 158, _T("&#1604;"));
	NewEntry(4, 155, _T("&#1602;"));
	NewEntry(4, 162, _T("&#1608;"));
	NewEntry(4, 152, _T("&#1593;"));
	NewEntry(4, 142, _T("&#1585;"));
	NewEntry(4, 132, _T("&#1578;"));
	NewEntry(4, 165, _T("&#1746;"));
	NewEntry(4, 163, _T("&#1574;"));
	NewEntry(4, 164, _T("&#1740;"));
	NewEntry(4, 166, _T("&#1729;"));
	NewEntry(4, 131, _T("&#1662;"));
	NewEntry(4, 141, _T("&#1584;"));
	NewEntry(4, 145, _T("&#1688;"));
	NewEntry(4, 134, _T("&#1579;"));
	NewEntry(4, 151, _T("&#1592;"));
	NewEntry(4, 161, _T("&#1722;"));
	NewEntry(4, 148, _T("&#1589;"));
	NewEntry(4, 140, _T("&#1672;"));
	NewEntry(4, 153, _T("&#1594;"));
	NewEntry(4, 137, _T("&#1581;"));
	NewEntry(4, 149, _T("&#1590;"));
	NewEntry(4, 138, _T("&#1582;"));
	NewEntry(4, 143, _T("&#1681;"));
	NewEntry(4, 133, _T("&#1657;"));
	NewEntry(4, 185, _T("&#1731;"));

	// mix
	NewEntry(4, 200, _T("&#1570;"));	// alif+madda
	NewEntry(4, 201, _T("&#1571;"));	// alif + hamza above
	
	// tashkeel/ aerab
	NewEntry(4, 168, _T("&#1613;"));	// kasratan
	NewEntry(4, 179, _T("&#1619;"));	// madda 
	NewEntry(4, 189, _T("&#1648;"));	// 
	NewEntry(4, 190, _T("&#1623;"));	// ulta paish
	NewEntry(4, 191, _T("&#1620;"));	// hamza above	
	NewEntry(4, 170, _T("&#1616;"));	// zair
	NewEntry(4, 171, _T("&#1614;"));	// zabar
	NewEntry(4, 207, _T("&#1556;"));	// takhallus
	NewEntry(4, 202, _T("&#1573;"));	// alif neechay hamza
	NewEntry(4, 247, _T("&#1537;"));	// sanh	(year mark)

	// special char
	NewEntry(4, 219, _T("&#64830;"));	// inpage bracket 
	NewEntry(4, 220, _T("&#64831;"));	// inpage bracket
	NewEntry(4, 32, _T(" "));			// space	
	NewEntry(4, 237, _T("&#1548;"));	// comma
	NewEntry(4, 232, _T("&#1645;"));	// sitara
	NewEntry(4, 243, _T("&#1748;"));	// dash
	NewEntry(4, 177, _T("&#1618;"));	// jazm sada	// 1624 = small noon ghunna & 1618 = sukun
	NewEntry(4, 180, _T("&#1624;"));	// jazm gol		// THIS MAY BE WRONG!!!
	NewEntry(4, 242, _T("&#1538;"));	// 
	NewEntry(4, 234, _T("&#1563;"));	// 
	NewEntry(4, 252, _T("."));	// 
	NewEntry(4, 253, _T("&#8216;"));	// left quote
	NewEntry(4, 254, _T("&#8217;"));	// right quote
	NewEntry(4, 250, _T("]"));	// 
	NewEntry(4, 251, _T("["));	// 
	NewEntry(4, 199, _T("&#1611;"));	// fathan
	NewEntry(4, 209, _T("&#1777;"));	// 1
	NewEntry(4, 210, _T("&#1778;"));	// 2
	NewEntry(4, 211, _T("&#1779;"));	// 3
	NewEntry(4, 212, _T("&#1780;"));	// 4
	NewEntry(4, 213, _T("&#1781;"));	// .
	NewEntry(4, 214, _T("&#1782;"));	// .
	NewEntry(4, 215, _T("&#1783;"));	// .
	NewEntry(4, 216, _T("&#1784;"));	// .
	NewEntry(4, 217, _T("&#1785;"));	// .
	NewEntry(4, 208, _T("&#1776;"));	// 0
	NewEntry(4, 230, _T("&#1555;"));	// razi allah unho

	NewEntry(4, 176, _T("&#1622;"));	// 
	NewEntry(4, 172, _T("&#1615;"));	// paish
	NewEntry(4, 231, _T("&#1554;"));	// 
	NewEntry(4, 233, _T(":"));			// 
	NewEntry(4, 223, _T("/"));			// 
	NewEntry(4, 224, _T("&#1748; &#1748; &#1748; "));			// ...... special inpage symbol
	NewEntry(4, 203, _T("&#65010;"));	// lillah glyph single
	NewEntry(4, 169, _T("&#1748;"));	// 

	NewEntry(4, 241, _T("!"));	// 
	NewEntry(4, 249, _T("&#1644;"));	// 
	NewEntry(4, 218, _T("!"));	// 
	NewEntry(4, 184, _T("&#1610;"));	// 
	NewEntry(4, 182, _T("&#1572;"));	// 

	NewEntry(4, 129, _T("&#1575;"));	// 
	NewEntry(4, 248, _T("&#1552;"));	// 
	NewEntry(4, 238, _T("&#1567;"));	// ?
	NewEntry(4, 181, _T("&#1612;"));	// 
	NewEntry(4, 225, _T(")"));	// 
	NewEntry(4, 226, _T("("));	// 
	
	NewEntry(4, 245, _T("&#1748;"));	// urdu dash
	NewEntry(4, 246, _T("&#65018;"));	// saw
	NewEntry(4, 174, _T("&#1553;"));	// aleh slam
	NewEntry(4, 173, _T("&#1617;"));	//	

	// ignore list
	NewEntry(4, 8, _T(""));	//	

	// MISC

	//10 + 13
	NewEntry(-1, 10, _T(""));		// carriage return
	NewEntry(-1, 13, _T("<br>"));	// line feed	
	NewEntry(-1, 34, _T("\""));	// "

	// tab
	//NewEntry(-1, 9, _T("    "));	// tab
	NewEntry(-1, 9, _T("\t"));	// tab

	// ASCII

	NewEntry(-1, 33, _T("!"));
	NewEntry(-1, 34, _T("\""));
	NewEntry(-1, 35, _T("#"));
	NewEntry(-1, 36, _T("$"));
	NewEntry(-1, 37, _T("%"));
	NewEntry(-1, 38, _T("&"));
	NewEntry(-1, 39, _T("'"));
	NewEntry(-1, 40, _T("("));
	NewEntry(-1, 41, _T(")"));
	NewEntry(-1, 42, _T("*"));
	NewEntry(-1, 43, _T("+"));
	NewEntry(-1, 44, _T(","));
	NewEntry(-1, 45, _T("-"));
	NewEntry(-1, 46, _T("."));
	NewEntry(-1, 47, _T("/"));
	NewEntry(-1, 48, _T("0"));
	NewEntry(-1, 49, _T("1"));
	NewEntry(-1, 50, _T("2"));
	NewEntry(-1, 51, _T("3"));
	NewEntry(-1, 52, _T("4"));
	NewEntry(-1, 53, _T("5"));
	NewEntry(-1, 54, _T("6"));
	NewEntry(-1, 55, _T("7"));
	NewEntry(-1, 56, _T("8"));
	NewEntry(-1, 57, _T("9"));
	NewEntry(-1, 58, _T(":"));
	NewEntry(-1, 59, _T(";"));
	NewEntry(-1, 60, _T("<"));
	NewEntry(-1, 61, _T("="));
	NewEntry(-1, 62, _T(">"));
	NewEntry(-1, 63, _T("?"));
	NewEntry(-1, 64, _T("@"));
	NewEntry(-1, 65, _T("A"));
	NewEntry(-1, 66, _T("B"));
	NewEntry(-1, 67, _T("C"));
	NewEntry(-1, 68, _T("D"));
	NewEntry(-1, 69, _T("E"));
	NewEntry(-1, 70, _T("F"));
	NewEntry(-1, 71, _T("G"));
	NewEntry(-1, 72, _T("H"));
	NewEntry(-1, 73, _T("I"));
	NewEntry(-1, 74, _T("J"));
	NewEntry(-1, 75, _T("K"));
	NewEntry(-1, 76, _T("L"));
	NewEntry(-1, 77, _T("M"));
	NewEntry(-1, 78, _T("N"));
	NewEntry(-1, 79, _T("O"));
	NewEntry(-1, 80, _T("P"));
	NewEntry(-1, 81, _T("Q"));
	NewEntry(-1, 82, _T("R"));
	NewEntry(-1, 83, _T("S"));
	NewEntry(-1, 84, _T("T"));
	NewEntry(-1, 85, _T("U"));
	NewEntry(-1, 86, _T("V"));
	NewEntry(-1, 87, _T("W"));
	NewEntry(-1, 88, _T("X"));
	NewEntry(-1, 89, _T("Y"));
	NewEntry(-1, 90, _T("Z"));
	NewEntry(-1, 91, _T("["));
	NewEntry(-1, 92, _T("\\"));
	NewEntry(-1, 93, _T("]"));
	NewEntry(-1, 94, _T("^"));
	NewEntry(-1, 95, _T("_"));
	NewEntry(-1, 96, _T("`"));
	NewEntry(-1, 97, _T("a"));
	NewEntry(-1, 98, _T("b"));
	NewEntry(-1, 99, _T("c"));
	NewEntry(-1, 100, _T("d"));
	NewEntry(-1, 101, _T("e"));
	NewEntry(-1, 102, _T("f"));
	NewEntry(-1, 103, _T("g"));
	NewEntry(-1, 104, _T("h"));
	NewEntry(-1, 105, _T("i"));
	NewEntry(-1, 106, _T("j"));
	NewEntry(-1, 107, _T("k"));
	NewEntry(-1, 108, _T("l"));
	NewEntry(-1, 109, _T("m"));
	NewEntry(-1, 110, _T("n"));
	NewEntry(-1, 111, _T("o"));
	NewEntry(-1, 112, _T("p"));
	NewEntry(-1, 113, _T("q"));
	NewEntry(-1, 114, _T("r"));
	NewEntry(-1, 115, _T("s"));
	NewEntry(-1, 116, _T("t"));
	NewEntry(-1, 117, _T("u"));
	NewEntry(-1, 118, _T("v"));
	NewEntry(-1, 119, _T("w"));
	NewEntry(-1, 120, _T("x"));
	NewEntry(-1, 121, _T("y"));
	NewEntry(-1, 122, _T("z"));
	NewEntry(-1, 123, _T("{"));
	NewEntry(-1, 124, _T("|"));
	NewEntry(-1, 125, _T("}"));
	NewEntry(-1, 126, _T("~"));
	
	NewEntry(-1, 32, _T(" "));		// space

	// post correct list
	// this list for all those characters that want
	// to save themselves from auto-correction

	NewEntry(4, 183, _T("__SP__{001}__"));	// ئ of inpage -> &#1574;

	return E_OK;
}

int CInpage2UniDlg::LookUp(BYTE left, BYTE right, CString& sNCR)
{
	INT_PTR len = m_lstInpageStruct.GetCount();
	
	for (int i = 0; i < len; i++)
	{
		CInpageStruct& s = m_lstInpageStruct[i];

		if (left == s.left && right == s.right)
		{
			sNCR = s.urduNCR;

			return E_OK;
		}
	}

	return E_NOTFOUND;
}

void CInpage2UniDlg::NewEntry(BYTE left, BYTE right, CString urduNCR)
{
	CInpageStruct s;

	s.left = left;
	s.right = right;
	s.urduNCR = urduNCR;

	m_lstInpageStruct.Add(s);
}

bool CInpage2UniDlg::WriteToHTMLFile()
{
	CStdioFile file;

	file.Open(m_strOutHTMLFile, CStdioFile::modeCreate | CStdioFile::modeWrite);

	file.WriteString(_T("<html>"));

	file.WriteString(_T("<head>\r\n"));
	file.WriteString(_T("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\r\n"));	
	file.WriteString(_T("<title>Converted Unicode Text</title>\r\n"));
	file.WriteString(_T("</head>\r\n"));

	file.WriteString(_T("<body dir=rtl>\r\n"));
	file.WriteString(_T("<font face='Nafees Web Naskh, Tahoma'>\r\n"));	
	
	file.WriteString(_T("<!-- Note: To view complete text easily, apply 'Word Wrap' command in editor -->\r\n"));	
	file.WriteString(m_sOutput);	
	
	file.WriteString(_T("</font>\r\n"));
	file.WriteString(_T("</body>\r\n"));

	file.WriteString(_T("</html>\r\n"));
	
	return true;
}

bool CInpage2UniDlg::WriteToTextFile()
{
	CStdioFile_UTF8 fileOut;
	CString sOutFile = m_strInFilePath + ".utf8.txt";
	CString sFileData = NCR2Unicode(m_sOutput);

	try 
	{
		if (fileOut.Open(sOutFile, CFile::modeCreate | CFile::modeWrite) != 0)
		{
			fileOut.WriteString(sFileData);
			
			if (m_Settings.WriteBOM())
			{
				fileOut.WriteBOM();
			}

			fileOut.Close();
		}
		else
		{
			m_strStatusText = _T("Error: Writing output text file.");
			UpdateData(FALSE);

			return false;
		}
	}
	catch(CFileException* ex)
	{
		m_strStatusText = _T("Error: Writing output text file.");
		UpdateData(FALSE);

		ex->Delete();
		fileOut.Close();
	
		return false;
	}
	
	return true;
}

// performs corrections
int CInpage2UniDlg::Correct()
{
	int m_iCorrections = 0;

	// compound form: hey hamza
	if (m_Settings.CorrectCompundHeyHamza())
	{
		m_iCorrections += m_sOutput.Replace(_T("&#1729;&#1569;"), _T("&#1730;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1729;&#1620;"), _T("&#1730;"));
	}
	
	// ئ errors
	// issue with 4 163
	// bna		&#1569;
	// banayay	&#1574;
	// banayay	&#1747;	// jointed single form

	if (m_Settings.CorrectHamzaInitialMedialForms())
	{
		m_iCorrections += m_sOutput.Replace(_T("&#1574; "), _T("&#1569; "));
		m_iCorrections += m_sOutput.Replace(_T("&#1574;<br>"), _T("&#1569;<br>"));
		m_iCorrections += m_sOutput.Replace(_T("&#1574;&#1748;"), _T("&#1569;&#1748;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1574;:"), _T("&#1569;:"));
		m_iCorrections += m_sOutput.Replace(_T("&#1574;&#1548;"), _T("&#1569;&#1548;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1574;&#1748;"), _T("&#1569;&#1748;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1574;&#1563;"), _T("&#1569;&#1563;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1574;!"), _T("&#1569;!"));
		
		// beside urdu number
		m_iCorrections += m_sOutput.Replace(_T("&#1777;&#1574;"), _T("&#1777;&#1569;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1778;&#1574;"), _T("&#1778;&#1569;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1779;&#1574;"), _T("&#1779;&#1569;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1780;&#1574;"), _T("&#1780;&#1569;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1781;&#1574;"), _T("&#1781;&#1569;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1782;&#1574;"), _T("&#1782;&#1569;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1783;&#1574;"), _T("&#1783;&#1569;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1784;&#1574;"), _T("&#1784;&#1569;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1785;&#1574;"), _T("&#1785;&#1569;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1776;&#1574;"), _T("&#1776;&#1569;"));
	}
	
	// ے coming in between letters

	if (m_Settings.CorrectMedialBarriYeh())	
	{
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1569;"), _T("&#1740;&#1574;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1586;"), _T("&#1740;&#1586;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1588;"), _T("&#1740;&#1588;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1670;"), _T("&#1740;&#1670;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1591;"), _T("&#1740;&#1591;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1576;"), _T("&#1740;&#1576;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1606;"), _T("&#1740;&#1606;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1605;"), _T("&#1740;&#1605;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1575;"), _T("&#1740;&#1575;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1587;"), _T("&#1740;&#1587;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1583;"), _T("&#1740;&#1583;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1601;"), _T("&#1740;&#1601;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1711;"), _T("&#1740;&#1711;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1726;"), _T("&#1740;&#1726;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1580;"), _T("&#1740;&#1580;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1705;"), _T("&#1740;&#1705;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1604;"), _T("&#1740;&#1604;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1602;"), _T("&#1740;&#1602;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1608;"), _T("&#1740;&#1608;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1593;"), _T("&#1740;&#1593;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1585;"), _T("&#1740;&#1585;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1578;"), _T("&#1740;&#1578;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1746;"), _T("&#1740;&#1746;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1729;"), _T("&#1740;&#1729;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1662;"), _T("&#1740;&#1662;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1584;"), _T("&#1740;&#1584;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1688;"), _T("&#1740;&#1688;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1579;"), _T("&#1740;&#1579;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1592;"), _T("&#1740;&#1592;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1722;"), _T("&#1740;&#1722;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1589;"), _T("&#1740;&#1589;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1672;"), _T("&#1740;&#1672;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1594;"), _T("&#1740;&#1594;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1581;"), _T("&#1740;&#1581;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1590;"), _T("&#1740;&#1590;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1582;"), _T("&#1740;&#1582;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1681;"), _T("&#1740;&#1681;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1657;"), _T("&#1740;&#1657;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1746;&#1731;"), _T("&#1740;&#1731;"));
	}

	// compound form: hey hamza
	if (m_Settings.CorrectCompundHeyHamza())
	{
		m_iCorrections += m_sOutput.Replace(_T("&#1729;&#1569;"), _T("&#1730;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1729;&#1620;"), _T("&#1730;"));
	}

	// compound form: alif + madda
	if (m_Settings.CorrectCompundAlifMadda())
	{
		m_iCorrections += m_sOutput.Replace(_T("&#1575;&#1619;"), _T("&#1570;"));
	}

	// hamza + wow
	if (m_Settings.CorrectCompundHamzaWoW())
	{
		m_iCorrections += m_sOutput.Replace(_T("&#1574;&#1608;"), _T("&#1572;"));
		m_iCorrections += m_sOutput.Replace(_T("&#1608;&#1620;"), _T("&#1572;"));
	}

	// double zabar to tanveen
	if (m_Settings.CorrectDoZabar2Tanween())
	{
		m_iCorrections += m_sOutput.Replace(_T("&#1614;&#1614;"), _T("&#1611;"));
	}

	// &#1569;&#1608; -> &#1572;

	// Orphan aerab
	if (m_Settings.CorrectOrphanAerab())
	{
		m_iCorrections += m_sOutput.Replace(_T(" &#1613;"), _T("&#1613;"));
		m_iCorrections += m_sOutput.Replace(_T(" &#1619;"), _T("&#1619;"));
		m_iCorrections += m_sOutput.Replace(_T(" &#1648;"), _T("&#1648;"));
		m_iCorrections += m_sOutput.Replace(_T(" &#1623;"), _T("&#1623;"));
		m_iCorrections += m_sOutput.Replace(_T(" &#1620;"), _T("&#1620;"));
		m_iCorrections += m_sOutput.Replace(_T(" &#1616;"), _T("&#1616;"));
		m_iCorrections += m_sOutput.Replace(_T(" &#1614;"), _T("&#1614;"));
	}

	return m_iCorrections;
}

// performs post correction routines
int CInpage2UniDlg::PostCorrect()
{
	int corr = 0;
	
	corr += m_sOutput.Replace(_T("__SP__{001}__"), _T("&#1574;"));

	return corr;
}

void CInpage2UniDlg::OnBnClickedButtonBrowse()
{
	CString sFilter = _T("Inpage Exported Text Files (*.txt)|*.txt|All Files (*.*)|*.*||");
	CFileDialog dlg(TRUE, _T(".txt"), NULL, 0, sFilter);
	
	if (dlg.DoModal() == IDOK)
	{
		m_strInFilePath = dlg.GetPathName();
		m_strOutHTMLFile = m_strInFilePath;
		m_strOutHTMLFile = m_strInFilePath + _T(".html");

		UpdateData(FALSE);
	}
}

void CInpage2UniDlg::OnBnClickedButtonView()
{
	UpdateData(FALSE);
	
	if (m_strOutHTMLFile != _T(""))
	{
		::ShellExecute(GetSafeHwnd(), _T("open"), m_strOutHTMLFile, _T(""), _T("C:\\"), SW_SHOWNORMAL);
		//::ShellExecute(GetSafeHwnd(), _T("open"), m_strOutHTMLFile, _T(""), CUtility::GetExeDir(), SW_SHOWNORMAL);
	}
}

CString CInpage2UniDlg::NCR2Unicode(CString sFileData)
{
	sFileData.Replace(_T("&#1586;"), _T("ز"));
	sFileData.Replace(_T("&#1588;"), _T("ش"));
	sFileData.Replace(_T("&#1670;"), _T("چ"));
	sFileData.Replace(_T("&#1591;"), _T("ط"));
	sFileData.Replace(_T("&#1576;"), _T("ب"));
	sFileData.Replace(_T("&#1606;"), _T("ن"));
	sFileData.Replace(_T("&#1605;"), _T("م"));
	sFileData.Replace(_T("&#1575;"), _T("ا"));
	sFileData.Replace(_T("&#1587;"), _T("س"));
	sFileData.Replace(_T("&#1583;"), _T("د"));
	sFileData.Replace(_T("&#1601;"), _T("ف"));
	sFileData.Replace(_T("&#1711;"), _T("گ"));
	sFileData.Replace(_T("&#1726;"), _T("ھ"));
	sFileData.Replace(_T("&#1580;"), _T("ج"));
	sFileData.Replace(_T("&#1705;"), _T("ک"));
	sFileData.Replace(_T("&#1604;"), _T("ل"));
	sFileData.Replace(_T("&#1602;"), _T("ق"));
	sFileData.Replace(_T("&#1608;"), _T("و"));
	sFileData.Replace(_T("&#1593;"), _T("ع"));
	sFileData.Replace(_T("&#1585;"), _T("ر"));
	sFileData.Replace(_T("&#1578;"), _T("ت"));
	sFileData.Replace(_T("&#1746;"), _T("ے"));
	sFileData.Replace(_T("&#1574;"), _T("ئ"));
	sFileData.Replace(_T("&#1740;"), _T("ی"));
	sFileData.Replace(_T("&#1729;"), _T("ہ"));
	sFileData.Replace(_T("&#1662;"), _T("پ"));
	sFileData.Replace(_T("&#1584;"), _T("ذ"));
	sFileData.Replace(_T("&#1688;"), _T("ژ"));
	sFileData.Replace(_T("&#1579;"), _T("ث"));
	sFileData.Replace(_T("&#1592;"), _T("ظ"));
	sFileData.Replace(_T("&#1722;"), _T("ں"));
	sFileData.Replace(_T("&#1589;"), _T("ص"));
	sFileData.Replace(_T("&#1672;"), _T("ڈ"));
	sFileData.Replace(_T("&#1594;"), _T("غ"));
	sFileData.Replace(_T("&#1581;"), _T("ح"));
	sFileData.Replace(_T("&#1590;"), _T("ض"));
	sFileData.Replace(_T("&#1582;"), _T("خ"));
	sFileData.Replace(_T("&#1681;"), _T("ڑ"));
	sFileData.Replace(_T("&#1657;"), _T("ٹ"));
	sFileData.Replace(_T("&#1731;"), _T("ۃ"));
	sFileData.Replace(_T("&#1570;"), _T("آ"));
	sFileData.Replace(_T("&#1571;"), _T("أ"));
	sFileData.Replace(_T("&#1613;"), _T("ٍ"));
	sFileData.Replace(_T("&#1619;"), _T("ٓ"));
	sFileData.Replace(_T("&#1648;"), _T("ٰ"));
	sFileData.Replace(_T("&#1623;"), _T("ٗ"));
	sFileData.Replace(_T("&#1620;"), _T("ٔ"));
	sFileData.Replace(_T("&#1616;"), _T("ِ"));
	sFileData.Replace(_T("&#1614;"), _T("َ"));
	sFileData.Replace(_T("&#1556;"), _T("ؔ"));
	sFileData.Replace(_T("&#1573;"), _T("إ"));
	sFileData.Replace(_T("&#1537;"), _T("؁"));
	sFileData.Replace(_T("&#1548;"), _T("،"));
	sFileData.Replace(_T("&#1645;"), _T("٭"));
	sFileData.Replace(_T("&#1748;"), _T("۔"));
	sFileData.Replace(_T("&#1618;"), _T("ْ"));
	sFileData.Replace(_T("&#1624;"), _T("٘"));
	sFileData.Replace(_T("&#1538;"), _T("؂"));
	sFileData.Replace(_T("&#1563;"), _T("؛"));
	sFileData.Replace(_T("&#8216;"), _T("‘"));
	sFileData.Replace(_T("&#8217;"), _T("’"));
	sFileData.Replace(_T("&#1611;"), _T("ً"));
	sFileData.Replace(_T("&#1777;"), _T("۱"));
	sFileData.Replace(_T("&#1778;"), _T("۲"));
	sFileData.Replace(_T("&#1779;"), _T("۳"));
	sFileData.Replace(_T("&#1780;"), _T("۴"));
	sFileData.Replace(_T("&#1781;"), _T("۵"));
	sFileData.Replace(_T("&#1782;"), _T("۶"));
	sFileData.Replace(_T("&#1783;"), _T("۷"));
	sFileData.Replace(_T("&#1784;"), _T("۸"));
	sFileData.Replace(_T("&#1785;"), _T("۹"));
	sFileData.Replace(_T("&#1776;"), _T("۰"));
	sFileData.Replace(_T("&#1555;"), _T("ؓ"));
	sFileData.Replace(_T("&#1622;"), _T("ٖ"));
	sFileData.Replace(_T("&#1615;"), _T("ُ"));
	sFileData.Replace(_T("&#1554;"), _T("ؒ"));
	sFileData.Replace(_T("&#1748;"), _T("۔"));
	sFileData.Replace(_T("&#1644;"), _T("٬"));
	sFileData.Replace(_T("&#1610;"), _T("ي"));
	sFileData.Replace(_T("&#1572;"), _T("ؤ"));
	sFileData.Replace(_T("&#1575;"), _T("ا"));
	sFileData.Replace(_T("&#1552;"), _T("ؐ"));
	sFileData.Replace(_T("&#1567;"), _T("؟"));
	sFileData.Replace(_T("&#1612;"), _T("ٌ"));
	sFileData.Replace(_T("&#1748;"), _T("۔"));
	sFileData.Replace(_T("&#1553;"), _T("ؑ"));
	sFileData.Replace(_T("&#1617;"), _T("ّ"));
	sFileData.Replace(_T("&#65010;"), _T("ﷲ"));
	sFileData.Replace(_T("&#65018;"), _T("ﷺ"));
	sFileData.Replace(_T("&#1748; &#1748; &#1748;"), _T("۔ ۔ ۔"));

	sFileData.Replace(_T("&#64830;"), _T("﴾"));
	sFileData.Replace(_T("&#64831;"), _T("﴿"));

	// more		
	sFileData.Replace(_T("&#1548;"), _T("،"));
	sFileData.Replace(_T("&#1563;"), _T("؛"));
	sFileData.Replace(_T("&#1569;"), _T("ء"));
	sFileData.Replace(_T("&#1570;"), _T("آ"));
	sFileData.Replace(_T("&#1572;"), _T("ؤ"));
	sFileData.Replace(_T("&#1574;"), _T("ئ"));
	sFileData.Replace(_T("&#1575;"), _T("ا"));
	sFileData.Replace(_T("&#1576;"), _T("ب"));
	sFileData.Replace(_T("&#1578;"), _T("ت"));
	sFileData.Replace(_T("&#1579;"), _T("ث"));
	sFileData.Replace(_T("&#1580;"), _T("ج"));
	sFileData.Replace(_T("&#1581;"), _T("ح"));
	sFileData.Replace(_T("&#1582;"), _T("خ"));
	sFileData.Replace(_T("&#1583;"), _T("د"));
	sFileData.Replace(_T("&#1584;"), _T("ذ"));
	sFileData.Replace(_T("&#1585;"), _T("ر"));
	sFileData.Replace(_T("&#1586;"), _T("ز"));
	sFileData.Replace(_T("&#1587;"), _T("س"));
	sFileData.Replace(_T("&#1588;"), _T("ش"));
	sFileData.Replace(_T("&#1589;"), _T("ص"));
	sFileData.Replace(_T("&#1590;"), _T("ض"));
	sFileData.Replace(_T("&#1591;"), _T("ط"));
	sFileData.Replace(_T("&#1592;"), _T("ظ"));
	sFileData.Replace(_T("&#1593;"), _T("ع"));
	sFileData.Replace(_T("&#1594;"), _T("غ"));
	sFileData.Replace(_T("&#1601;"), _T("ف"));
	sFileData.Replace(_T("&#1602;"), _T("ق"));
	sFileData.Replace(_T("&#1604;"), _T("ل"));
	sFileData.Replace(_T("&#1605;"), _T("م"));
	sFileData.Replace(_T("&#1606;"), _T("ن"));
	sFileData.Replace(_T("&#1608;"), _T("و"));
	sFileData.Replace(_T("&#1611;"), _T("ً"));
	sFileData.Replace(_T("&#1613;"), _T("ٍ"));
	sFileData.Replace(_T("&#1614;"), _T("َ"));
	sFileData.Replace(_T("&#1616;"), _T("ِ"));
	sFileData.Replace(_T("&#1619;"), _T("ٓ"));
	sFileData.Replace(_T("&#1620;"), _T("ٔ"));
	sFileData.Replace(_T("&#1623;"), _T("ٗ"));
	sFileData.Replace(_T("&#1648;"), _T("ٰ"));
	sFileData.Replace(_T("&#1657;"), _T("ٹ"));
	sFileData.Replace(_T("&#1662;"), _T("پ"));
	sFileData.Replace(_T("&#1670;"), _T("چ"));
	sFileData.Replace(_T("&#1672;"), _T("ڈ"));
	sFileData.Replace(_T("&#1681;"), _T("ڑ"));
	sFileData.Replace(_T("&#1688;"), _T("ژ"));
	sFileData.Replace(_T("&#1705;"), _T("ک"));
	sFileData.Replace(_T("&#1711;"), _T("گ"));
	sFileData.Replace(_T("&#1722;"), _T("ں"));
	sFileData.Replace(_T("&#1726;"), _T("ھ"));
	sFileData.Replace(_T("&#1729;"), _T("ہ"));
	sFileData.Replace(_T("&#1730;"), _T("ۂ"));
	sFileData.Replace(_T("&#1731;"), _T("ۃ"));
	sFileData.Replace(_T("&#1740;"), _T("ی"));
	sFileData.Replace(_T("&#1748;"), _T("۔"));
	sFileData.Replace(_T("&#1776;"), _T("۰"));
	sFileData.Replace(_T("&#1777;"), _T("۱"));
	sFileData.Replace(_T("&#1778;"), _T("۲"));
	sFileData.Replace(_T("&#1779;"), _T("۳"));
	sFileData.Replace(_T("&#1780;"), _T("۴"));
	sFileData.Replace(_T("&#1781;"), _T("۵"));
	sFileData.Replace(_T("&#1782;"), _T("۶"));
	sFileData.Replace(_T("&#1783;"), _T("۷"));
	sFileData.Replace(_T("&#1784;"), _T("۸"));
	sFileData.Replace(_T("&#1785;"), _T("۹"));

	//
	// specials
	//

	// 04/MAY/2007: updated on aijaz saheb request (i think it wa wrong before)
	//sFileData.Replace(_T("<br>"), _T("\r\n"));
	sFileData.Replace(_T("<br>"), _T("\n"));

	// kachra
	sFileData.Replace(_T("췍"), _T(""));
	sFileData.Replace(_T("촀"), _T(""));		
	sFileData.Replace(_T("﷽"), _T(""));		
	sFileData.Replace(_T("﷽"), _T(""));		
	sFileData.Replace(_T("ˀ"), _T(""));
	sFileData.Replace(_T("ˀ"), _T(""));

	return sFileData;
}

// cleans all internal variables
void CInpage2UniDlg::CleanUp()
{
	if (m_pData)
	{
		delete[] m_pData;
		m_pData = 0;
	}		
	
	m_iCorrections = 0;
	m_sOutput = _T("");
	m_iUnResolved = 0;
}

int CInpage2UniDlg::ReadExternalReplacementFile(CString sExternalReplacementFileName)
{
	m_lstReplaceItems.RemoveAll();

	// read sExternalReplacementFileName in array
	// return array size read
	CString sFileName = CUtility::GetExeDir();
	sFileName += sExternalReplacementFileName;	

	// read sFileName 
	// load m_lstReplaceItems
	
	string line;
	ifstream myfile (sFileName);
	
	if (myfile.is_open())
	{
		while (!myfile.eof())
		{
			getline (myfile, line);

			CReplaceItem ri;
			CUtility::Explode(line.c_str(), _T('='), ri.sBadString, ri.sGoodString);

			m_lstReplaceItems.Add(ri);
		}

		myfile.close();
	}

	else
	{
		AfxMessageBox(_T("Unable to open file"));
	}

	return (int) m_lstReplaceItems.GetCount();
}

int CInpage2UniDlg::ExternalReplace()
{
	int replaced = 0;
	int sz = (int) m_lstReplaceItems.GetCount();

	for (int i = 0; i < sz; i++)
	{
		CReplaceItem& ri = m_lstReplaceItems[i];

		replaced += m_sOutput.Replace(ri.sBadString, ri.sGoodString);
	}
	
	return replaced;
}
