--------------------------
How to use
--------------------------

. Run Inpage
. Open Inpage file (.inp)
. Select text to export
. Click File > Export 
. Give file name (with .txt as extension)
. Run Inpage to Unicode converter (Inpage2Uni.exe)
. Browse to exported inpage file
. Press convert
. Examine output
	. html file (filename + .html)
	. txt file (filename + .utf8.txt)

--------------------------
Program settings
--------------------------

. To change program settings, open 'inp2uni.ini' 
  file in a text editor and update.

*New in v0.9.4*
 External replacements file now in Unicode format (no more NCR strings)

*New in v0.9.3*
 Use of external replacements file to correct common errors

--------------------------
Contact information
--------------------------

Shariq Mustaquim
shariqmus@yahoo.co.uk
http://www.boriat.com/inpagetounicode/
